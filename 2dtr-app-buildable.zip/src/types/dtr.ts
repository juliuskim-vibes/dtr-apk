export interface DtrEntry {
  date: string;          // YYYY-MM-DD
  dayOfMonth: number;    // 1..31
  activities: string;
  remarks: string;
  photoPath?: string | null;  // For legacy/single-photo compatibility
  photos?: string[];          // Multiple photos support per day
  status: 'Accomplishment' | 'Accomplished' | 'Leave' | 'Official Travel' | 'Weekend';
}

export interface DayUiModel {
  date: string;          // YYYY-MM-DD
  dayOfMonth: number;
  dayOfWeekName: string; // Mon, Tue, etc.
  fullDayName: string;   // Monday, Tuesday
  isWeekend: boolean;
  isSaturday: boolean;
  isSunday: boolean;
  activities: string;
  remarks: string;
  photoPath?: string | null;
  photos?: string[];
  status: 'Accomplishment' | 'Accomplished' | 'Leave' | 'Official Travel' | 'Weekend';
  isCustomized: boolean;
}

/**
 * Returns all photo paths/data URLs for a day entry, ensuring
 * backward compatibility between single photoPath and multiple photos array.
 */
export function getEntryPhotos(item: { photos?: string[]; photoPath?: string | null }): string[] {
  if (Array.isArray(item.photos) && item.photos.length > 0) {
    return item.photos.filter((p) => typeof p === 'string' && p.trim().length > 0);
  }
  if (item.photoPath && typeof item.photoPath === 'string' && item.photoPath.trim().length > 0) {
    return [item.photoPath];
  }
  return [];
}

export interface InstitutionalMetadata {
  // Employee Profile
  employeeName: string;
  employeePosition: string;

  // Verified By: Immediate Head
  verifiedByName: string;
  verifiedByPosition: string;

  // Approved By: Campus Director / University Head
  approvedByName: string;
  approvedByPosition: string;

  // Institutional Info
  agencyOrInstitution: string;
  campusAddress: string;
  contactNumber: string;
  website: string;
}

export interface MonthlyStats {
  totalDays: number;
  accomplishedDays: number;
  ongoingDays: number;
  leaveDays: number;
  weekendDays: number;
  photosAttached: number;
}
