import React from 'react';
import { Database, FileText, Camera, Smartphone, Layers, CheckCircle2, AlertTriangle, Code2 } from 'lucide-react';

export const ArchitectureGuide: React.FC = () => {
  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Overview Banner */}
      <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
        <h2 className="text-lg font-bold text-slate-900 dark:text-white">
          Principal Android Developer Architecture Guide
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
          Comprehensive offline-first engineering blueprint for the Daily Time Record (DTR) and Monthly Accomplishment Report generator.
        </p>
      </div>

      {/* 4 Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pillar 1: Room DB */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 shadow-xs">
          <div className="flex items-center gap-2.5 text-blue-600 dark:text-blue-400 font-bold text-sm">
            <Database className="w-5 h-5" />
            <h3>1. Room Database (2.6.1) Offline Concurrency</h3>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            The schema uses an ISO date string (<code className="text-blue-600 dark:text-blue-400 font-mono">YYYY-MM-DD</code>) as the natural primary key, guaranteeing idempotency during updates.
          </p>
          <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-400 list-disc list-inside">
            <li>
              <strong>Monthly Prefix Matching:</strong> Queries like <code className="font-mono text-[11px]">SELECT * FROM dtr_entries WHERE date LIKE '2026-10-%'</code> allow indexed chronological scanning without complex timestamp math.
            </li>
            <li>
              <strong>Reactive Flow Streaming:</strong> Room's DAO emits a reactive Kotlin Flow that triggers Jetpack Compose recomposition whenever any daily record is saved or updated.
            </li>
            <li>
              <strong>Coroutines Dispatcher:</strong> All database mutations execute on <code className="font-mono text-[11px]">Dispatchers.IO</code> via ViewModel scope, keeping the Compose UI thread at 60/120fps.
            </li>
          </ul>
        </div>

        {/* Pillar 2: Apache POI */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 shadow-xs">
          <div className="flex items-center gap-2.5 text-emerald-600 dark:text-emerald-400 font-bold text-sm">
            <FileText className="w-5 h-5" />
            <h3>2. Apache POI (5.2.5) .DOCX Engine & Packaging</h3>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Apache POI generates standard OpenXML Word processing packages (<code className="font-mono text-[11px]">.docx</code>) matching strict institutional guidelines.
          </p>
          <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-400 list-disc list-inside">
            <li>
              <strong>Preventing DuplicateFileException:</strong> Apache POI bundles conflicting XML schema definitions and notice files. In <code className="font-mono text-[11px]">build.gradle.kts</code>, <code className="font-mono text-[11px]">packaging.resources.excludes</code> suppresses duplicate <code className="font-mono text-[11px]">META-INF</code> files.
            </li>
            <li>
              <strong>Table Geometry in Twips:</strong> Cell dimensions are explicitly defined in twips (1/20th of a point; 9600 twips = 6.67 inches), ensuring exact table alignment across all Word versions.
            </li>
            <li>
              <strong>Auto-Populated Month Schedule:</strong> Evaluates every day from 1 to the end of month (28..31) and fills weekend tags automatically.
            </li>
          </ul>
        </div>

        {/* Pillar 3: Camera & FileProvider */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 shadow-xs">
          <div className="flex items-center gap-2.5 text-amber-600 dark:text-amber-400 font-bold text-sm">
            <Camera className="w-5 h-5" />
            <h3>3. Camera Capture & Scoped Storage Security</h3>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Modern Android photo proof management without requiring invasive runtime storage permissions.
          </p>
          <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-400 list-disc list-inside">
            <li>
              <strong>ActivityResultContracts.TakePicture:</strong> Launches system camera with a secure <code className="font-mono text-[11px]">content://</code> URI generated via <code className="font-mono text-[11px]">FileProvider</code>.
            </li>
            <li>
              <strong>Internal Storage Isolation:</strong> Images are saved into <code className="font-mono text-[11px]">context.filesDir/photos/</code>, making them private to the app, persistent across updates, and safe from external tampering.
            </li>
            <li>
              <strong>Coil AsyncImage Loader:</strong> Thumbnail previews are loaded asynchronously with memory-efficient downsampling to eliminate Out-Of-Memory (OOM) risks.
            </li>
          </ul>
        </div>

        {/* Pillar 4: Compose Material 3 */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 shadow-xs">
          <div className="flex items-center gap-2.5 text-purple-600 dark:text-purple-400 font-bold text-sm">
            <Smartphone className="w-5 h-5" />
            <h3>4. Jetpack Compose Material 3 UX</h3>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Reactive, single-direction data flow with hoisted state and clean institutional aesthetics.
          </p>
          <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-400 list-disc list-inside">
            <li>
              <strong>Month/Year Selector:</strong> Instant month stepping with real-time recalculation of calendar days and statistics.
            </li>
            <li>
              <strong>Modal BottomSheet Editor:</strong> Smooth entry dialog containing multiline accomplishments, status dropdown, remarks chips, and photo capture.
            </li>
            <li>
              <strong>Public Downloads Export:</strong> Writes the resulting <code className="font-mono text-[11px]">.docx</code> to <code className="font-mono text-[11px]">MediaStore.Downloads</code> so users can immediately attach it to email or transfer to flash drives.
            </li>
          </ul>
        </div>
      </div>

      {/* Setup Instructions */}
      <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Code2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          Importing into Android Studio (Step-by-Step)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-800 dark:text-slate-200">1. Download ZIP</span>
            <p className="text-slate-600 dark:text-slate-400">
              Click the &quot;Download Android Project (.ZIP)&quot; button in the top navigation bar. Extract the archive into your development workspace folder.
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-800 dark:text-slate-200">2. Open in Android Studio</span>
            <p className="text-slate-600 dark:text-slate-400">
              Launch Android Studio (Ladybug, Koala, or Jellyfish). Select <em>Open</em> and choose the extracted project directory. Allow Gradle to sync.
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-800 dark:text-slate-200">3. Build & Run</span>
            <p className="text-slate-600 dark:text-slate-400">
              Run on any Android device or emulator running API 26 (Android 8.0) or higher. The app is completely offline-ready out of the box.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
