import { DtrEntry } from '../types/dtr';

export const SAMPLE_ACCOMPLISHMENTS = [
  'Official travel to Mindanao State University–Iligan Institute of Technology (MSU-IIT).',
  'Consolidated supporting documents for PPMP submissions and organized research terminal reports for documentation and recordkeeping.',
  'Developed a data-tracking document to facilitate the monitoring, organization, and archiving of Research Office records and activities.',
  'Reviewed and examined Planning Office files to verify documentation and identify records requiring consolidation.',
  'Provided multimedia technical support during the flag-raising ceremony and drafted proposals for the FY 2027 PPMP.',
  'Assisted the Planning Office in gathering, organizing, and consolidating institutional data and supporting documents for reporting purposes.',
  'Coordinated with concerned personnel regarding approved research proposals and related documentation requirements.',
  'Conducted follow-up communications concerning approved research proposals to support coordination and documentation activities.',
  'Assisted in compiling and organizing institutional records and supporting data required for Planning Office reporting.',
  'Served as multimedia support personnel during the flag-raising ceremony and prepared supporting documents for Research Office PPMP revisions.',
  'Gathered and consolidated institutional data and supporting documents for Planning Office reporting requirements.',
  'Continued compiling, organizing, and documenting institutional data and records for Planning Office requirements.',
  'Official travel to Cagwait to attend IA-related activities.',
  'Assisted the Planning Office in gathering and compiling institutional data required for submission to the Philippine Association of State Universities and Colleges (PASUC).',
  'Continued consolidating and organizing institutional data and supporting documents for PASUC reporting requirements.',
  'Reviewed and compiled institutional records and supporting information necessary for PASUC data submission.',
  'Coordinated and conducted follow-ups with concerned personnel regarding approved research proposals and related documentation.',
];

/**
 * Creates an authentic sample photographic proof data URL with an official date tag.
 * Compact dimensions and optimized compression keep storage footprint small (<10KB)
 * while maintaining crystal-clear institutional text and date tags.
 */
export function createSampleProofDataUrl(dateStr: string, label: string, location: string): string {
  if (typeof document === 'undefined') return '';
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 360;
    canvas.height = 220;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    // Dark sleek backdrop simulating camera snapshot
    const grad = ctx.createLinearGradient(0, 0, 360, 220);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(1, '#1e293b');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 360, 220);

    // Border line
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(8, 8, 344, 204);

    // Institutional Banner
    ctx.fillStyle = '#1e3a8a';
    ctx.fillRect(16, 16, 328, 30);

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 10px Arial, sans-serif';
    ctx.fillText('NEMSU · MEANS OF VERIFICATION (MOV)', 24, 35);

    // DATE TAG (High visibility yellow-amber badge matching official audit standards)
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(16, 54, 180, 22);
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 10px Arial, sans-serif';
    ctx.fillText(`DATE TAG: ${dateStr}`, 22, 69);

    // Activity description
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px Arial, sans-serif';
    ctx.fillText(label.slice(0, 42), 16, 96);
    if (label.length > 42) {
      ctx.fillText(label.slice(42, 84), 16, 112);
    }

    // Location & details
    ctx.fillStyle = '#94a3b8';
    ctx.font = '9px Arial, sans-serif';
    ctx.fillText(`Official Location: ${location}`, 16, 140);
    ctx.fillText('Attached Photographic Proof of Institutional Duty', 16, 156);

    // Sensor & timestamp stamp
    ctx.fillStyle = '#64748b';
    ctx.font = '8px monospace';
    ctx.fillText(`PHOTO PROOF #NEMSU-${dateStr.replace(/-/g, '')}-MOV`, 16, 192);

    return canvas.toDataURL('image/jpeg', 0.6);
  } catch (e) {
    console.error('Failed creating canvas sample photo:', e);
    return '';
  }
}

export function generateSampleMonthEntries(year: number, month: number): DtrEntry[] {
  const daysInMonth = new Date(year, month, 0).getDate();
  const entries: DtrEntry[] = [];

  for (let day = 1; day <= daysInMonth; day++) {
    const dateObj = new Date(year, month - 1, day);
    const dayOfWeek = dateObj.getDay(); // 0 is Sunday, 6 is Saturday
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

    if (dayOfWeek === 0) {
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: 'SUNDAY',
        remarks: '',
        status: 'Weekend',
        photoPath: null,
      });
    } else if (dayOfWeek === 6) {
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: 'SATURDAY',
        remarks: '',
        status: 'Weekend',
        photoPath: null,
      });
    } else if (day === 5 || day === 30) {
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: 'Leave',
        remarks: '',
        status: 'Leave',
        photoPath: null,
      });
    } else if (day === 8 || day === 15) {
      // Sample Ongoing tasks
      const taskIndex = (day - 1) % SAMPLE_ACCOMPLISHMENTS.length;
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: SAMPLE_ACCOMPLISHMENTS[taskIndex],
        remarks: 'Ongoing',
        status: 'Accomplishment',
        photoPath: null,
      });
    } else if (day === 1 || day === 2) {
      const photos: string[] = [];
      if (day === 1) {
        photos.push(
          createSampleProofDataUrl(
            dateStr,
            'Official travel to Mindanao State University–Iligan Institute of Technology (MSU-IIT)',
            'MSU-IIT, Iligan City'
          )
        );
        photos.push(
          createSampleProofDataUrl(
            dateStr,
            'Consultation and benchmarking of IT curricula with MSU-IIT faculty',
            'College of Computer Studies, MSU-IIT'
          )
        );
      }
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: 'Official travel to Mindanao State University–Iligan Institute of Technology (MSU-IIT).',
        remarks: 'Official Travel',
        status: 'Accomplishment',
        photoPath: photos[0] || null,
        photos,
      });
    } else if (day === 6) {
      const photo = createSampleProofDataUrl(dateStr, 'PPMP Submissions & Research Terminal Reports Documentation', 'Research Office, NEMSU');
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: SAMPLE_ACCOMPLISHMENTS[1],
        remarks: 'Accomplished',
        status: 'Accomplishment',
        photoPath: photo,
        photos: photo ? [photo] : [],
      });
    } else if (day === 12) {
      const photo = createSampleProofDataUrl(dateStr, 'Flag-raising technical and multimedia support', 'Administration Grounds, NEMSU');
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: SAMPLE_ACCOMPLISHMENTS[4],
        remarks: 'Accomplished',
        status: 'Accomplishment',
        photoPath: photo,
        photos: photo ? [photo] : [],
      });
    } else if (day === 18) {
      // Sample WFH (Work From Home) entry
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: SAMPLE_ACCOMPLISHMENTS[6],
        remarks: 'WFH',
        status: 'Accomplishment',
        photoPath: null,
      });
    } else if (day === 22 || day === 23) {
      const photo = day === 22 ? createSampleProofDataUrl(dateStr, 'Official travel to Cagwait to attend IA-related activities', 'Cagwait, Surigao del Sur') : null;
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: 'Official travel to Cagwait to attend IA-related activities.',
        remarks: 'Official Travel',
        status: 'Accomplishment',
        photoPath: photo,
        photos: photo ? [photo] : [],
      });
    } else {
      const taskIndex = (day - 1) % SAMPLE_ACCOMPLISHMENTS.length;
      entries.push({
        date: dateStr,
        dayOfMonth: day,
        activities: SAMPLE_ACCOMPLISHMENTS[taskIndex],
        remarks: 'Accomplished',
        status: 'Accomplishment',
        photoPath: null,
      });
    }
  }

  return entries;
}
