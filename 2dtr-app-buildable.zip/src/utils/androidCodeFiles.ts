import JSZip from 'jszip';
import { downloadBlob } from './docxExport';

export interface AndroidCodeFile {
  id: string;
  name: string;
  path: string;
  category: 'build' | 'database' | 'util' | 'ui' | 'config';
  language: 'kotlin' | 'xml' | 'groovy' | 'markdown';
  description: string;
  content: string;
}

export const ANDROID_FILES: AndroidCodeFile[] = [
  {
    id: 'build_gradle_app',
    name: 'build.gradle.kts (:app)',
    path: 'app/build.gradle.kts',
    category: 'build',
    language: 'kotlin',
    description: 'App-level Gradle script with Compose M3, Room 2.6.1, Coil, Apache POI 5.2.5, and packaging exclusions.',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
    id("kotlin-parcelize")
}

android {
    namespace = "com.institutional.dtreporter"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.institutional.dtreporter"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi"
        )
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.15"
    }

    // CRITICAL: Apache POI 5.2.5 packaging exclusions to avoid DuplicateFileException
    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/license.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt",
                "META-INF/notice.txt",
                "META-INF/INDEX.LIST",
                "META-INF/*.SF",
                "META-INF/*.DSA",
                "META-INF/*.RSA"
            )
        }
    }
}

dependencies {
    // Android Core & Lifecycle
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.10.1")

    // Jetpack Compose BOM & Material 3
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.material:material-icons-extended")

    // Room Database (Version 2.6.1 requested)
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // Coil for image preview (io.coil-kt:coil-compose requested)
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Apache POI for official .docx generation (Version 5.2.5 requested)
    implementation("org.apache.poi:poi-ooxml:5.2.5")

    // Core library desugaring for Java 8+ time APIs
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")

    debugImplementation("androidx.compose.ui:ui-tooling")
}`
  },
  {
    id: 'dtr_entry',
    name: 'DtrEntry.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/data/DtrEntry.kt',
    category: 'database',
    language: 'kotlin',
    description: 'Room Entity with date primary key (YYYY-MM-DD), dayOfMonth, activities, remarks, photoPath, and status.',
    content: `package com.institutional.dtreporter.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing a single Daily Time Record (DTR) and Accomplishment log entry.
 */
@Entity(tableName = "dtr_entries")
data class DtrEntry(
    @PrimaryKey
    val date: String,             // Format: "YYYY-MM-DD"
    val dayOfMonth: Int,          // 1 .. 31
    val activities: String = "",  // Accomplishment text
    val remarks: String = "",     // Auto-filled or customized remark
    val photoPath: String? = null,// Path in context.filesDir
    val status: String = "Accomplished" // Accomplished | Leave | Official Travel | Weekend
)`
  },
  {
    id: 'dtr_dao',
    name: 'DtrDao.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/data/DtrDao.kt',
    category: 'database',
    language: 'kotlin',
    description: 'Room DAO providing reactive Flow observation for month prefix matching and atomic upsert operations.',
    content: `package com.institutional.dtreporter.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DtrDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(entry: DtrEntry)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entries: List<DtrEntry>)

    @Query("SELECT * FROM dtr_entries WHERE date LIKE :monthPrefix ORDER BY dayOfMonth ASC")
    fun getEntriesForMonth(monthPrefix: String): Flow<List<DtrEntry>>

    @Query("SELECT * FROM dtr_entries WHERE date = :date LIMIT 1")
    suspend fun getEntryByDate(date: String): DtrEntry?

    @Delete
    suspend fun delete(entry: DtrEntry)

    @Query("DELETE FROM dtr_entries WHERE date LIKE :monthPrefix")
    suspend fun deleteMonth(monthPrefix: String)

    @Query("SELECT COUNT(*) FROM dtr_entries WHERE date LIKE :monthPrefix AND photoPath IS NOT NULL AND photoPath != ''")
    fun countPhotosForMonth(monthPrefix: String): Flow<Int>

    @Query("UPDATE dtr_entries SET photoPath = NULL WHERE date LIKE :monthPrefix")
    suspend fun clearPhotosForMonth(monthPrefix: String): Int
}`
  },
  {
    id: 'app_database',
    name: 'AppDatabase.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/data/AppDatabase.kt',
    category: 'database',
    language: 'kotlin',
    description: 'Thread-safe Singleton Room database instance with fallbackToDestructiveMigration().',
    content: `package com.institutional.dtreporter.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [DtrEntry::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun dtrDao(): DtrDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "institutional_dtr_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}`
  },
  {
    id: 'file_util',
    name: 'FileUtil.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/util/FileUtil.kt',
    category: 'util',
    language: 'kotlin',
    description: 'Camera TakePicture helper, FileProvider URI generator, internal storage caching, and scoped storage Downloads stream.',
    content: `package com.institutional.dtreporter.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileUtil {

    private const val PHOTO_DIR_NAME = "photos"
    private const val CACHE_DIR_NAME = "camera_captures"

    fun createCameraTempUri(context: Context): Uri {
        val cacheFolder = File(context.cacheDir, CACHE_DIR_NAME).apply {
            if (!exists()) mkdirs()
        }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val tempFile = File.createTempFile("PROOF_\${timeStamp}_", ".jpg", cacheFolder)
        val authority = "\${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, tempFile)
    }

    fun saveBitmapToInternalStorage(context: Context, bitmap: Bitmap, dateKey: String): String {
        val photosDir = File(context.filesDir, PHOTO_DIR_NAME).apply {
            if (!exists()) mkdirs()
        }
        val destinationFile = File(photosDir, "DTR_PROOF_\${dateKey}.jpg")
        FileOutputStream(destinationFile).use { outStream ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outStream)
            outStream.flush()
        }
        return destinationFile.absolutePath
    }

    fun copyUriToInternalStorage(context: Context, sourceUri: Uri, dateKey: String): String? {
        return try {
            val photosDir = File(context.filesDir, PHOTO_DIR_NAME).apply {
                if (!exists()) mkdirs()
            }
            val destinationFile = File(photosDir, "DTR_PROOF_\${dateKey}.jpg")
            val inputStream: InputStream? = context.contentResolver.openInputStream(sourceUri)
            inputStream?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            destinationFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun deleteInternalPhoto(filePath: String?): Boolean {
        if (filePath.isNullOrBlank()) return false
        val file = File(filePath)
        return if (file.exists()) file.delete() else false
    }

    fun openDownloadsOutputStream(
        context: Context,
        fileName: String,
        mimeType: String = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ): Pair<OutputStream?, String?> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                Pair(context.contentResolver.openOutputStream(uri), "Downloads/$fileName")
            } else {
                Pair(null, null)
            }
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val targetFile = File(downloadsDir, fileName)
            Pair(FileOutputStream(targetFile), targetFile.absolutePath)
        }
    }
}`
  },
  {
    id: 'word_exporter',
    name: 'WordExporter.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/util/WordExporter.kt',
    category: 'util',
    language: 'kotlin',
    description: 'Apache POI .docx generator with centered bold 12pt header, 3-column table, auto weekend tags, and sign-off lines.',
    content: `package com.institutional.dtreporter.util

import android.content.Context
import com.institutional.dtreporter.data.DtrEntry
import org.apache.poi.xwpf.usermodel.*
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd
import java.io.OutputStream
import java.math.BigInteger
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class ExportResult(
    val isSuccess: Boolean,
    val filePath: String? = null,
    val errorMessage: String? = null
)

data class InstitutionalMetadata(
    val employeeName: String = "JONATHAN K. LUCAGBO",
    val employeePosition: String = "Instructor I",
    val verifiedByName: String = "ENGR. REYNALDO T. VELEZ, M.ENG.",
    val verifiedByPosition: String = "Department Head, Information Technology",
    val approvedByName: String = "DR. NEMESIO G. LOAYON",
    val approvedByPosition: String = "Campus Director",
    val agencyOrInstitution: String = "North Eastern Mindanao State University",
    val campusAddress: String = "San Miguel, Surigao del Sur 8301",
    val contactNumber: String = "09463014014",
    val website: String = "www.nemsu.edu.ph"
)

object WordExporter {

    private const val FONT_ARIAL = "Arial"
    private const val HEADER_BLUE = "BDD7EE"

    fun exportMonthlyReport(
        context: Context,
        yearMonth: YearMonth,
        savedEntries: List<DtrEntry>,
        metadata: InstitutionalMetadata = InstitutionalMetadata()
    ): ExportResult {
        return try {
            val document = XWPFDocument()

            // Folio / Philippine Long (8.5 x 13 inches): 12240 x 18720 dxa, 0.75 in margins = 1080 twips
            val docSect = document.document.body.sectPr ?: document.document.body.addNewSectPr()
            val pageSz = docSect.pgSz ?: docSect.addNewPgSz()
            pageSz.w = BigInteger.valueOf(12240) // 8.5 inches * 1440
            pageSz.h = BigInteger.valueOf(18720) // 13.0 inches * 1440 (Folio / F4)
            val pageMar = docSect.pgMar ?: docSect.addNewPgMar()
            pageMar.top = BigInteger.valueOf(1080)
            pageMar.bottom = BigInteger.valueOf(1080)
            pageMar.left = BigInteger.valueOf(1080)
            pageMar.right = BigInteger.valueOf(1080)

            // 1. Institution Header
            val instPara = document.createParagraph().apply {
                alignment = ParagraphAlignment.CENTER
                spacingAfter = 140
            }
            instPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 10
                setText("Republic of the Philippines")
                addBreak()
            }
            instPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 12
                isBold = true
                setText(metadata.agencyOrInstitution.uppercase(Locale.ROOT))
                addBreak()
                addBreak()
            }
            instPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 11
                isBold = true
                setText("ACCOMPLISHMENT REPORT")
                addBreak()
            }
            val monthYearTitle = yearMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)).uppercase(Locale.ROOT)
            instPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 10
                isBold = true
                setText("MONTH OF $monthYearTitle")
            }

            // 2. Sub-Header: Name (Left) and Position (Right)
            val subTable = document.createTable(1, 2).apply {
                tableAlignment = TableRowAlign.CENTER
                width = 9600
            }
            val nameCell = subTable.getRow(0).getCell(0).apply { width = 5000 }
            nameCell.paragraphs[0].apply {
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText("Name: ")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText(metadata.employeeName.uppercase(Locale.ROOT))
                }
            }
            val posCell = subTable.getRow(0).getCell(1).apply { width = 4600 }
            posCell.paragraphs[0].apply {
                alignment = ParagraphAlignment.RIGHT
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText("Position: ")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText(metadata.employeePosition)
                }
            }

            document.createParagraph().apply { spacingAfter = 100 }

            // 3. Construct 3-Column Table (Date | Activities | Remarks)
            val table = document.createTable().apply {
                tableAlignment = TableRowAlign.CENTER
                width = 9600
            }
            val headerRow = table.getRow(0) ?: table.createRow()
            headerRow.isRepeatHeader = true
            val colWidths = intArrayOf(1000, 7000, 1600)
            val headerTitles = arrayOf("Date", "Activities", "Remarks")

            for (i in headerTitles.indices) {
                val cell = if (i == 0) headerRow.getCell(0) else headerRow.addNewTableCell()
                cell.width = colWidths[i]
                setCellShading(cell, HEADER_BLUE)

                cell.paragraphs[0].apply {
                    alignment = ParagraphAlignment.CENTER
                    spacingBefore = 60
                    spacingAfter = 60
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 10
                        isBold = true
                        setText(headerTitles[i])
                    }
                }
            }

            val daysInMonth = yearMonth.lengthOfMonth()
            val entriesMap = savedEntries.associateBy { it.dayOfMonth }

            for (day in 1..daysInMonth) {
                val currentDate = LocalDate.of(yearMonth.year, yearMonth.month, day)
                val dayOfWeek = currentDate.dayOfWeek
                val isSat = dayOfWeek == DayOfWeek.SATURDAY
                val isSun = dayOfWeek == DayOfWeek.SUNDAY

                val savedEntry = entriesMap[day]
                var activitiesText = savedEntry?.activities?.trim().orEmpty()
                var remarksText = savedEntry?.remarks?.trim().orEmpty()

                if (isSat) {
                    activitiesText = "SATURDAY"
                    remarksText = ""
                } else if (isSun) {
                    activitiesText = "SUNDAY"
                    remarksText = ""
                } else if (savedEntry?.status == "Leave" || activitiesText.contains("leave", ignoreCase = true)) {
                    if (activitiesText.isEmpty()) activitiesText = "Leave"
                    remarksText = "" // Strictly no remark for leave
                } else {
                    if (remarksText.isEmpty() && activitiesText.isNotEmpty()) {
                        remarksText = "Accomplished"
                    }
                }

                val row: XWPFTableRow = table.createRow()

                // Col 1: Date (Day number only)
                val dateCell = row.getCell(0).apply { width = colWidths[0] }
                dateCell.paragraphs[0].apply {
                    alignment = ParagraphAlignment.CENTER
                    spacingBefore = 30
                    spacingAfter = 30
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 9
                        if (isSat || isSun) isBold = true
                        setText(day.toString())
                    }
                }

                // Col 2: Activities
                val actCell = row.getCell(1).apply { width = colWidths[1] }
                actCell.paragraphs[0].apply {
                    alignment = ParagraphAlignment.LEFT
                    spacingBefore = 30
                    spacingAfter = 30
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 9
                        if (isSat || isSun) isBold = true
                        setText(activitiesText)
                    }
                }

                // Col 3: Remarks
                val remCell = row.getCell(2).apply { width = colWidths[2] }
                remCell.paragraphs[0].apply {
                    alignment = ParagraphAlignment.CENTER
                    spacingBefore = 30
                    spacingAfter = 30
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 9
                        setText(remarksText)
                    }
                }
            }

            // Institutional Footer Page 1
            document.createParagraph().apply {
                spacingBefore = 240
                spacingAfter = 200
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 8
                    setText("\${metadata.campusAddress} · \${metadata.contactNumber} · \${metadata.website}")
                }
            }

            // Page 2: Signatories
            document.createParagraph().apply {
                isPageBreak = true
                spacingBefore = 200
            }

            // Top Row: Prepared by & Verified by
            val topSignTable = document.createTable(1, 2).apply {
                tableAlignment = TableRowAlign.CENTER
                width = 9600
            }

            // Prepared by
            topSignTable.getRow(0).getCell(0).apply { width = 4800 }.paragraphs[0].apply {
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText("Prepared by:\\n\\n\\n\\n")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText(metadata.employeeName.uppercase(Locale.ROOT))
                    addBreak()
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 9
                    setText(metadata.employeePosition)
                }
            }

            // Verified by
            topSignTable.getRow(0).getCell(1).apply { width = 4800 }.paragraphs[0].apply {
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText("Verified by:\\n\\n\\n\\n")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText(metadata.verifiedByName.uppercase(Locale.ROOT))
                    addBreak()
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 9
                    setText(metadata.verifiedByPosition)
                }
            }

            // Approved by (Center)
            document.createParagraph().apply { spacingBefore = 400 }
            val appTable = document.createTable(1, 1).apply {
                tableAlignment = TableRowAlign.CENTER
                width = 9600
            }
            appTable.getRow(0).getCell(0).apply { width = 9600 }.paragraphs[0].apply {
                alignment = ParagraphAlignment.CENTER
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText("Approved by:\\n\\n\\n\\n")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText(metadata.approvedByName.uppercase(Locale.ROOT))
                    addBreak()
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 9
                    setText(metadata.approvedByPosition)
            // Page 3+: ATTACHMENTS FOR VERIFICATION (1 Dedicated Page Per Photo)
            entries.filter { !it.photoPath.isNullOrBlank() }.forEachIndexed { index, entry ->
                document.createParagraph().apply {
                    isPageBreak = true
                    alignment = ParagraphAlignment.CENTER
                    spacingBefore = 200
                    spacingAfter = 100
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 13
                        isBold = true
                        setText("ATTACHMENTS FOR VERIFICATION")
                    }
                }

                document.createParagraph().apply {
                    alignment = ParagraphAlignment.LEFT
                    spacingBefore = 60
                    spacingAfter = 120
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 10
                        isBold = true
                        setText("Date: ")
                    }
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 10
                        setText("\${entry.date}\\n")
                    }
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 10
                        isBold = true
                        setText("Activity: ")
                    }
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 10
                        setText(if (entry.activities.isNotBlank()) entry.activities else "Official duty logged")
                    }
                }

                // Dedicated clear & big photo attachment
                try {
                    val file = File(entry.photoPath ?: "")
                    if (file.exists()) {
                        document.createParagraph().apply {
                            alignment = ParagraphAlignment.CENTER
                            val imageRun = createRun()
                            FileInputStream(file).use { fis ->
                                imageRun.addPicture(
                                    fis,
                                    XWPFDocument.PICTURE_TYPE_JPEG,
                                    file.name,
                                    org.apache.poi.util.Units.toEMU(480.0),
                                    org.apache.poi.util.Units.toEMU(340.0)
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            // Output to Downloads
            val fileMonthStr = yearMonth.format(DateTimeFormatter.ofPattern("yyyy_MM", Locale.US))
            val sanitizedName = metadata.employeeName.replace("\\\\s+".toRegex(), "_")
            val fileName = "DTR_Accomplishment_Report_\${sanitizedName}_\${fileMonthStr}.docx"

            val (outputStream, savedPath) = FileUtil.openDownloadsOutputStream(context, fileName)
            if (outputStream == null) {
                return ExportResult(false, errorMessage = "Failed to obtain output stream for Downloads.")
            }

            outputStream.use { stream ->
                document.write(stream)
                stream.flush()
            }
            document.close()

            ExportResult(true, filePath = savedPath ?: "Downloads/$fileName")
        } catch (e: Exception) {
            e.printStackTrace()
            ExportResult(false, errorMessage = e.localizedMessage)
        }
    }

    private fun setCellShading(cell: XWPFTableCell, hexColor: String) {
        val tcPr = cell.ctTc.tcPr ?: cell.ctTc.addNewTcPr()
        val ctShd = tcPr.shd ?: tcPr.addNewShd()
        ctShd.setVal(STShd.CLEAR)
        ctShd.setColor("auto")
        ctShd.setFill(hexColor)
    }
}`
  },
  {
    id: 'main_viewmodel',
    name: 'MainViewModel.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/ui/MainViewModel.kt',
    category: 'ui',
    language: 'kotlin',
    description: 'StateFlow management, Room queries with month prefix matching, auto weekend tagging, and background export dispatcher.',
    content: `package com.institutional.dtreporter.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.institutional.dtreporter.data.*
import com.institutional.dtreporter.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class DayCardUiModel(
    val dateString: String,
    val dayOfMonth: Int,
    val dayOfWeekName: String,
    val isWeekend: Boolean,
    val isSaturday: Boolean,
    val isSunday: Boolean,
    val activities: String,
    val remarks: String,
    val photoPath: String?,
    val status: String,
    val isCustomized: Boolean
)

data class MonthlyStats(
    val totalDays: Int = 0,
    val accomplishedDays: Int = 0,
    val leaveDays: Int = 0,
    val travelDays: Int = 0,
    val weekendDays: Int = 0,
    val photosAttached: Int = 0
)

sealed interface ExportStatus {
    object Idle : ExportStatus
    object Exporting : ExportStatus
    data class Success(val filePath: String) : ExportStatus
    data class Error(val message: String) : ExportStatus
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val dtrDao: DtrDao = AppDatabase.getDatabase(application).dtrDao()

    private val _selectedYearMonth = MutableStateFlow(YearMonth.now())
    val selectedYearMonth: StateFlow<YearMonth> = _selectedYearMonth.asStateFlow()

    private val _metadata = MutableStateFlow(InstitutionalMetadata())
    val metadata: StateFlow<InstitutionalMetadata> = _metadata.asStateFlow()

    private val _exportStatus = MutableStateFlow<ExportStatus>(ExportStatus.Idle)
    val exportStatus: StateFlow<ExportStatus> = _exportStatus.asStateFlow()

    private val _editingDay = MutableStateFlow<DayCardUiModel?>(null)
    val editingDay: StateFlow<DayCardUiModel?> = _editingDay.asStateFlow()

    private val _filterQuery = MutableStateFlow("All")
    val filterQuery: StateFlow<String> = _filterQuery.asStateFlow()

    val monthlyEntries: StateFlow<List<DtrEntry>> = _selectedYearMonth
        .flatMapLatest { ym ->
            val monthPrefix = String.format(Locale.US, "%04d-%02d-%%", ym.year, ym.monthValue)
            dtrDao.getEntriesForMonth(monthPrefix)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val daysList: StateFlow<List<DayCardUiModel>> = combine(
        _selectedYearMonth,
        monthlyEntries,
        _filterQuery
    ) { ym, entries, filter ->
        val daysInMonth = ym.lengthOfMonth()
        val entryMap = entries.associateBy { it.dayOfMonth }

        val allDays = (1..daysInMonth).map { day ->
            val localDate = LocalDate.of(ym.year, ym.month, day)
            val dayOfWeek = localDate.dayOfWeek
            val isSat = dayOfWeek == DayOfWeek.SATURDAY
            val isSun = dayOfWeek == DayOfWeek.SUNDAY
            val isWeekend = isSat || isSun

            val saved = entryMap[day]
            val dateKey = localDate.format(DateTimeFormatter.ISO_LOCAL_DATE)

            val activities = saved?.activities ?: ""
            val defaultRemark = when {
                isSat -> "SATURDAY"
                isSun -> "SUNDAY"
                else -> ""
            }
            val remarks = saved?.remarks?.takeIf { it.isNotBlank() } ?: defaultRemark
            val status = saved?.status ?: if (isWeekend) "Weekend" else "Accomplished"

            DayCardUiModel(
                dateString = dateKey,
                dayOfMonth = day,
                dayOfWeekName = dayOfWeek.name.take(3).lowercase(Locale.ROOT).replaceFirstChar { it.titlecase(Locale.ROOT) },
                isWeekend = isWeekend,
                isSaturday = isSat,
                isSunday = isSun,
                activities = activities,
                remarks = remarks,
                photoPath = saved?.photoPath,
                status = status,
                isCustomized = saved != null
            )
        }

        when (filter) {
            "Weekdays" -> allDays.filter { !it.isWeekend }
            "Accomplished" -> allDays.filter { it.status == "Accomplished" && it.activities.isNotBlank() }
            "Leave" -> allDays.filter { it.status == "Leave" }
            "Official Travel" -> allDays.filter { it.status == "Official Travel" }
            "Photos" -> allDays.filter { !it.photoPath.isNullOrBlank() }
            else -> allDays
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun previousMonth() { _selectedYearMonth.value = _selectedYearMonth.value.minusMonths(1) }
    fun nextMonth() { _selectedYearMonth.value = _selectedYearMonth.value.plusMonths(1) }
    fun setFilter(filter: String) { _filterQuery.value = filter }
    fun updateMetadata(newMeta: InstitutionalMetadata) { _metadata.value = newMeta }
    fun openEditDialog(day: DayCardUiModel) { _editingDay.value = day }
    fun dismissEditDialog() { _editingDay.value = null }

    fun saveEntry(dateString: String, dayOfMonth: Int, activities: String, remarks: String, status: String, photoPath: String?) {
        viewModelScope.launch(Dispatchers.IO) {
            dtrDao.insertOrUpdate(
                DtrEntry(dateString, dayOfMonth, activities, remarks, photoPath, status)
            )
            _editingDay.value = null
        }
    }

    fun autoTagWeekends() {
        viewModelScope.launch(Dispatchers.IO) {
            val ym = _selectedYearMonth.value
            val daysInMonth = ym.lengthOfMonth()
            val entriesToInsert = mutableListOf<DtrEntry>()

            for (day in 1..daysInMonth) {
                val date = LocalDate.of(ym.year, ym.month, day)
                val isSat = date.dayOfWeek == DayOfWeek.SATURDAY
                val isSun = date.dayOfWeek == DayOfWeek.SUNDAY

                if (isSat || isSun) {
                    val dateKey = date.format(DateTimeFormatter.ISO_LOCAL_DATE)
                    val existing = dtrDao.getEntryByDate(dateKey)
                    if (existing == null) {
                        entriesToInsert.add(
                            DtrEntry(dateKey, day, "", if (isSat) "SATURDAY" else "SUNDAY", null, "Weekend")
                        )
                    }
                }
            }
            if (entriesToInsert.isNotEmpty()) dtrDao.insertAll(entriesToInsert)
        }
    }

    fun exportToWordDocument(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            _exportStatus.value = ExportStatus.Exporting
            val result = WordExporter.exportMonthlyReport(
                context, _selectedYearMonth.value, monthlyEntries.value, _metadata.value
            )
            if (result.isSuccess && result.filePath != null) {
                _exportStatus.value = ExportStatus.Success(result.filePath)
            } else {
                _exportStatus.value = ExportStatus.Error(result.errorMessage ?: "Export failed.")
            }
        }
    }

    fun dismissExportStatus() { _exportStatus.value = ExportStatus.Idle }
}`
  },
  {
    id: 'home_screen',
    name: 'HomeScreen.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/ui/HomeScreen.kt',
    category: 'ui',
    language: 'kotlin',
    description: 'Material 3 TopAppBar with Month/Year picker, monthly KPI strip, daily cards with Coil proof preview, FAB, and Export DOCX button.',
    content: `package com.institutional.dtreporter.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val selectedYearMonth by viewModel.selectedYearMonth.collectAsState()
    val daysList by viewModel.daysList.collectAsState()
    val exportStatus by viewModel.exportStatus.collectAsState()
    val editingDay by viewModel.editingDay.collectAsState()
    val filterQuery by viewModel.filterQuery.collectAsState()

    LaunchedEffect(exportStatus) {
        when (val status = exportStatus) {
            is ExportStatus.Success -> {
                snackbarHostState.showSnackbar("DOCX saved: \${status.filePath}", duration = SnackbarDuration.Long)
                viewModel.dismissExportStatus()
            }
            is ExportStatus.Error -> {
                snackbarHostState.showSnackbar("Error: \${status.message}", duration = SnackbarDuration.Long)
                viewModel.dismissExportStatus()
            }
            else -> Unit
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Daily Time Record", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(selectedYearMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)), style = MaterialTheme.typography.bodySmall)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.previousMonth() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Prev")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.nextMonth() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next")
                    }
                    IconButton(onClick = { viewModel.autoTagWeekends() }) {
                        Icon(Icons.Default.Weekend, contentDescription = "Auto-tag Weekends")
                    }
                    Button(
                        onClick = { viewModel.exportToWordDocument(context) },
                        enabled = exportStatus !is ExportStatus.Exporting,
                        modifier = Modifier.padding(end = 8.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export DOCX", fontSize = 12.sp)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    val today = LocalDate.now().dayOfMonth
                    val target = daysList.find { it.dayOfMonth == today } ?: daysList.firstOrNull()
                    target?.let { viewModel.openEditDialog(it) }
                },
                icon = { Icon(Icons.Default.EditCalendar, contentDescription = null) },
                text = { Text("Log Today") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(daysList, key = { it.dateString }) { dayModel ->
                DayCard(day = dayModel, onClick = { viewModel.openEditDialog(dayModel) })
            }
            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }

    editingDay?.let { day ->
        DailyEntryDialog(
            dayModel = day,
            onDismiss = { viewModel.dismissEditDialog() },
            onSave = { dStr, dNum, act, rem, stat, photo ->
                viewModel.saveEntry(dStr, dNum, act, rem, stat, photo)
            }
        )
    }
}

@Composable
fun DayCard(day: DayCardUiModel, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(
            containerColor = if (day.isWeekend) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(
                    if (day.isWeekend) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primaryContainer
                ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(String.format(Locale.US, "%02d", day.dayOfMonth), fontWeight = FontWeight.Bold)
                Text(day.dayOfWeekName, fontSize = 10.sp)
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        if (day.isWeekend && day.activities.isBlank()) "WEEKEND" else day.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = when (day.status) {
                            "Accomplished" -> Color(0xFF16A34A)
                            "Leave" -> Color(0xFFD97706)
                            "Official Travel" -> Color(0xFF2563EB)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    if (day.remarks.isNotBlank()) {
                        Text(day.remarks, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
                Text(
                    if (day.activities.isNotBlank()) day.activities else if (day.isWeekend) "Weekend — No official duty" else "No activities logged yet (Tap to edit)",
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (!day.photoPath.isNullOrBlank() && File(day.photoPath).exists()) {
                Spacer(modifier = Modifier.width(10.dp))
                AsyncImage(
                    model = File(day.photoPath),
                    contentDescription = "Proof",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(6.dp))
                )
            }
        }
    }
}`
  },
  {
    id: 'daily_entry_dialog',
    name: 'DailyEntryDialog.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/ui/DailyEntryDialog.kt',
    category: 'ui',
    language: 'kotlin',
    description: 'BottomSheet dialog with TakePicture camera integration, status dropdown, multiline activities field, remarks chips, and Coil image preview.',
    content: `package com.institutional.dtreporter.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.institutional.dtreporter.util.FileUtil
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyEntryDialog(
    dayModel: DayCardUiModel,
    onDismiss: () -> Unit,
    onSave: (dateString: String, dayOfMonth: Int, activities: String, remarks: String, status: String, photoPath: String?) -> Unit
) {
    val context = LocalContext.current
    var activities by remember { mutableStateOf(dayModel.activities) }
    var remarks by remember { mutableStateOf(dayModel.remarks) }
    var selectedStatus by remember { mutableStateOf(dayModel.status) }
    var currentPhotoPath by remember { mutableStateOf(dayModel.photoPath) }
    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }
    var statusDropdownExpanded by remember { mutableStateOf(false) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success && tempCameraUri != null) {
            val path = FileUtil.copyUriToInternalStorage(context, tempCameraUri!!, dayModel.dateString)
            if (path != null) currentPhotoPath = path
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp).verticalScroll(rememberScrollState())
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Day \${dayModel.dayOfMonth} · \${dayModel.dayOfWeekName}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(dayModel.dateString, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Status Dropdown
            // Workflow Status
            Text("Workflow Status", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Accomplishment", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Standard Status", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Activities text
            Text("Activities Undertaken", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = activities,
                onValueChange = {
                    activities = it
                    if (it.contains("leave", ignoreCase = true)) {
                        remarks = ""
                    }
                },
                placeholder = { Text("Log daily accomplishments or project tasks...") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                shape = RoundedCornerShape(12.dp),
                minLines = 4
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Remarks
            Text("Remarks / Official Tag", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = remarks,
                onValueChange = { remarks = it },
                placeholder = { Text("Accomplished, Ongoing, or leave blank") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Remarks Quick Selection Chips
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = remarks == "Accomplished",
                    onClick = { remarks = "Accomplished" },
                    label = { Text("Accomplished") }
                )
                FilterChip(
                    selected = remarks == "Ongoing",
                    onClick = { remarks = "Ongoing" },
                    label = { Text("Ongoing") }
                )
                FilterChip(
                    selected = remarks == "WFH",
                    onClick = { remarks = "WFH" },
                    label = { Text("WFH") }
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = remarks == "Official Travel",
                    onClick = { remarks = "Official Travel" },
                    label = { Text("Official Travel") }
                )
                FilterChip(
                    selected = remarks.isEmpty(),
                    onClick = { remarks = "" },
                    label = { Text("No Remark (Leave)") }
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Camera proof
            Text("Photographic Proof", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(8.dp))
            if (!currentPhotoPath.isNullOrBlank() && File(currentPhotoPath!!).exists()) {
                Box(modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(8.dp))) {
                    AsyncImage(model = File(currentPhotoPath!!), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
                TextButton(
                    onClick = {
                        FileUtil.deleteInternalPhoto(currentPhotoPath)
                        currentPhotoPath = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Remove Photo")
                }
            } else {
                OutlinedButton(
                    onClick = {
                        val uri = FileUtil.createCameraTempUri(context)
                        tempCameraUri = uri
                        cameraLauncher.launch(uri)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Capture Proof via Camera")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                Button(
                    onClick = {
                        val isLeave = activities.contains("leave", ignoreCase = true)
                        val finalStatus = if (isLeave) "Leave" else "Accomplishment"
                        val finalRemarks = if (isLeave) "" else remarks
                        onSave(dayModel.dateString, dayModel.dayOfMonth, activities, finalRemarks, finalStatus, currentPhotoPath)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Save")
                }
            }
        }
    }
}`
  },
  {
    id: 'main_activity',
    name: 'MainActivity.kt',
    path: 'app/src/main/java/com/institutional/dtreporter/MainActivity.kt',
    category: 'ui',
    language: 'kotlin',
    description: 'ComponentActivity entry point applying edge-to-edge Material 3 theme.',
    content: `package com.institutional.dtreporter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import com.institutional.dtreporter.ui.HomeScreen
import com.institutional.dtreporter.ui.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HomeScreen(viewModel = viewModel)
                }
            }
        }
    }
}`
  },
  {
    id: 'android_manifest',
    name: 'AndroidManifest.xml',
    path: 'app/src/main/AndroidManifest.xml',
    category: 'config',
    language: 'xml',
    description: 'Manifest declaring Camera permission, legacy storage limits, and FileProvider.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="DTR &amp; Accomplishment Reporter"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Material3.DayNight.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

    </application>

</manifest>`
  },
  {
    id: 'file_paths_xml',
    name: 'file_paths.xml',
    path: 'app/src/main/res/xml/file_paths.xml',
    category: 'config',
    language: 'xml',
    description: 'FileProvider internal and cache path definitions for safe camera URI sharing.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<paths xmlns:android="http://schemas.android.com/apk/res/android">
    <files-path name="dtr_internal_photos" path="photos/" />
    <cache-path name="dtr_cache_photos" path="camera_captures/" />
</paths>`
  },
  {
    id: 'proguard_rules',
    name: 'proguard-rules.pro',
    path: 'app/proguard-rules.pro',
    category: 'config',
    language: 'groovy',
    description: 'ProGuard/R8 obfuscation keeps for Room, Apache POI POI-OOXML schemas, and Coil.',
    content: `# Room Database
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Apache POI POI-OOXML
-dontwarn org.apache.poi.**
-dontwarn org.openxmlformats.**
-dontwarn schemasMicrosoftComOffice**
-dontwarn org.apache.xmlbeans.**
-keep class org.apache.poi.** { *; }
-keep class org.openxmlformats.** { *; }
-keep class org.apache.xmlbeans.** { *; }

# Coil image loader
-dontwarn coil.**
-keep class coil.** { *; }`
  }
];

/**
 * Generates and downloads a complete, ready-to-open Android Studio project ZIP
 */
export async function downloadAndroidProjectZip(): Promise<void> {
  const zip = new JSZip();

  // Root project files
  zip.file('build.gradle.kts', `// Top-level build file
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.compose.compiler) apply false
    alias(libs.plugins.ksp) apply false
}
`);

  zip.file('settings.gradle.kts', `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "DtrAccomplishmentReporter"
include(":app")
`);

  // Add all app files
  for (const file of ANDROID_FILES) {
    zip.file(file.path, file.content);
  }

  // Add gradle wrapper properties mockup
  zip.file('gradle/wrapper/gradle-wrapper.properties', `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`);

  zip.file('README.md', `# DTR & Accomplishment Reporter - Android Project
Complete offline Android app with Room 2.6.1, Jetpack Compose Material 3, Coil, and Apache POI 5.2.5.
Import into Android Studio Ladybug/Koala and run on device or emulator.
`);

  const content = await zip.generateAsync({ type: 'blob' });
  downloadBlob(content, 'DTR_Accomplishment_Reporter_Android_Project.zip');
}
