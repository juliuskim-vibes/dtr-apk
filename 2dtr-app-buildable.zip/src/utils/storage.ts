/**
 * Robust Offline Storage for DTR Records and Institutional Metadata.
 * 
 * Uses IndexedDB as the primary persistence layer (matching Android Room DB semantics)
 * with virtually unlimited quota, plus safe localStorage synchronization for instant
 * offline bootstrap that gracefully handles quota limits without crashing.
 */

import { DtrEntry, InstitutionalMetadata } from '../types/dtr';

const DB_NAME = 'NemsuDtrOfflineDb';
const DB_VERSION = 1;
const STORE_NAME = 'dtr_records';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported in this environment'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'date' });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

/**
 * Loads all DTR records from IndexedDB
 */
export async function loadRecordsFromIndexedDb(): Promise<Record<string, DtrEntry> | null> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const records = request.result as DtrEntry[];
        if (!records || records.length === 0) {
          resolve(null);
          return;
        }
        const map: Record<string, DtrEntry> = {};
        records.forEach((r) => {
          map[r.date] = r;
        });
        resolve(map);
      };

      request.onerror = () => {
        resolve(null);
      };
    });
  } catch (err) {
    console.warn('IndexedDB unavailable or failed, falling back to memory/localStorage:', err);
    return null;
  }
}

/**
 * Persists all DTR records into IndexedDB
 */
export async function saveRecordsToIndexedDb(records: Record<string, DtrEntry>): Promise<void> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);

      // Clear existing records before batch saving
      store.clear();

      Object.values(records).forEach((entry) => {
        store.put(entry);
      });

      tx.oncomplete = () => {
        resolve();
      };

      tx.onerror = () => {
        reject(tx.error);
      };
    });
  } catch (err) {
    console.warn('Failed saving to IndexedDB:', err);
  }
}

/**
 * Safely saves data to localStorage without crashing on QuotaExceededError.
 * Automatically cleanses heavy image data if localStorage is tight.
 */
export function safeLocalStorageSet(key: string, value: string): boolean {
  if (typeof window === 'undefined' || !window.localStorage) return false;
  try {
    window.localStorage.setItem(key, value);
    return true;
  } catch (e: unknown) {
    console.warn(`localStorage.setItem failed for key "${key}" (quota exceeded or restricted):`, e);
    try {
      // If quota exceeded, remove the bloated key so future calls don't repeatedly fail
      window.localStorage.removeItem(key);
    } catch {
      // Ignore
    }
    return false;
  }
}

/**
 * Safely reads from localStorage
 */
export function safeLocalStorageGet(key: string): string | null {
  if (typeof window === 'undefined' || !window.localStorage) return null;
  try {
    return window.localStorage.getItem(key);
  } catch (e) {
    console.warn(`localStorage.getItem failed for key "${key}":`, e);
    return null;
  }
}

/**
 * Strips heavy base64 photo strings for lightweight localStorage backup
 */
export function createLightweightRecordSummary(records: Record<string, DtrEntry>): string {
  const lightMap: Record<string, Omit<DtrEntry, 'photoPath' | 'photos'> & { photoCount: number; hasPhoto: boolean }> = {};
  for (const [date, entry] of Object.entries(records)) {
    const count = (entry.photos && entry.photos.length) || (entry.photoPath ? 1 : 0);
    lightMap[date] = {
      date: entry.date,
      dayOfMonth: entry.dayOfMonth,
      activities: entry.activities,
      remarks: entry.remarks,
      status: entry.status,
      photoCount: count,
      hasPhoto: count > 0,
    };
  }
  return JSON.stringify(lightMap);
}
