import {
  Document,
  Packer,
  Paragraph,
  Table,
  TableRow,
  TableCell,
  TextRun,
  AlignmentType,
  WidthType,
  BorderStyle,
  ImageRun,
} from 'docx';
import { DayUiModel, InstitutionalMetadata, getEntryPhotos } from '../types/dtr';

/**
 * Resolves an image path or data URL into binary bytes for docx ImageRun
 */
async function resolveImageBytes(src: string): Promise<{ data: Uint8Array; type: 'jpg' | 'png' } | null> {
  try {
    if (src.startsWith('data:')) {
      const isPng = src.startsWith('data:image/png');
      const base64 = src.split(',')[1];
      const binaryString = atob(base64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      return { data: bytes, type: isPng ? 'png' : 'jpg' };
    } else {
      const res = await fetch(src);
      const buf = await res.arrayBuffer();
      const isPng = src.toLowerCase().endsWith('.png');
      return { data: new Uint8Array(buf), type: isPng ? 'png' : 'jpg' };
    }
  } catch (e) {
    console.error('Failed to resolve image bytes for DOCX:', e);
    return null;
  }
}

/**
 * Generates an official Microsoft Word (.docx) Accomplishment Report
 * matching the exact institutional format of North Eastern Mindanao State University (NEMSU),
 * including Page 1 (Table), Page 2 (Signatories), and Page 3+ (Annex: Photographic Evidence with Date Tags).
 */
export async function exportAccomplishmentReportDocx(
  yearMonthStr: string, // e.g. "2026-10"
  monthTitle: string,   // e.g. "OCTOBER 2026"
  daysList: DayUiModel[],
  metadata: InstitutionalMetadata
): Promise<Blob> {
  const FONT_NAME = 'Times New Roman';
  const HEADER_BLUE = 'BDD7EE'; // Official NEMSU soft blue table header tint (#BDD7EE)

  // ================= 1. INSTITUTION HEADER =================
  const headerPara = new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 140, before: 0 },
    children: [
      new TextRun({
        text: 'Republic of the Philippines\n',
        font: FONT_NAME,
        size: 20, // 10pt
      }),
      new TextRun({
        text: metadata.agencyOrInstitution.toUpperCase() + '\n\n',
        font: FONT_NAME,
        size: 22, // 11pt
        bold: true,
      }),
      new TextRun({
        text: 'ACCOMPLISHMENT REPORT\n',
        font: FONT_NAME,
        size: 22, // 11pt
        bold: true,
      }),
      new TextRun({
        text: `MONTH OF ${monthTitle.toUpperCase()}`,
        font: FONT_NAME,
        size: 20, // 10pt
        bold: true,
      }),
    ],
  });

  // ================= 2. SUB-HEADER (Name & Position) =================
  const metaTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      bottom: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      left: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      right: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: 'auto' },
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: 55, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                children: [
                  new TextRun({ text: 'Name: ', font: FONT_NAME, size: 20, bold: true }),
                  new TextRun({ text: metadata.employeeName.toUpperCase(), font: FONT_NAME, size: 20 }),
                ],
              }),
            ],
          }),
          new TableCell({
            width: { size: 45, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({ text: 'Position: ', font: FONT_NAME, size: 20, bold: true }),
                  new TextRun({ text: metadata.employeePosition, font: FONT_NAME, size: 20 }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  const spacingPara = new Paragraph({ spacing: { after: 120 }, children: [] });

  // ================= 3. 3-COLUMN TABLE =================
  const headerRow = new TableRow({
    tableHeader: true,
    cantSplit: true,
    children: [
      new TableCell({
        width: { size: 10, type: WidthType.PERCENTAGE },
        shading: { fill: HEADER_BLUE },
        margins: { top: 80, bottom: 80, left: 60, right: 60 },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: 'Date', font: FONT_NAME, size: 20, bold: true })],
          }),
        ],
      }),
      new TableCell({
        width: { size: 72, type: WidthType.PERCENTAGE },
        shading: { fill: HEADER_BLUE },
        margins: { top: 80, bottom: 80, left: 100, right: 100 },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: 'Activities', font: FONT_NAME, size: 20, bold: true })],
          }),
        ],
      }),
      new TableCell({
        width: { size: 18, type: WidthType.PERCENTAGE },
        shading: { fill: HEADER_BLUE },
        margins: { top: 80, bottom: 80, left: 60, right: 60 },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: 'Remarks', font: FONT_NAME, size: 20, bold: true })],
          }),
        ],
      }),
    ],
  });

  const dataRows = daysList.map((day) => {
    const isSat = day.isSaturday;
    const isSun = day.isSunday;
    let activitiesText = day.activities.trim();
    let remarksText = day.remarks.trim();
    const isLeave = day.status === 'Leave' || activitiesText.toLowerCase().includes('leave');

    if (isSat) {
      activitiesText = 'SATURDAY';
      remarksText = '';
    } else if (isSun) {
      activitiesText = 'SUNDAY';
      remarksText = '';
    } else if (isLeave) {
      if (!activitiesText) activitiesText = 'Leave';
      remarksText = ''; // Strictly no remark for leave
    } else {
      if (!remarksText && activitiesText) {
        remarksText = 'Accomplished';
      }
    }

    return new TableRow({
      cantSplit: true,
      children: [
        // Date (just the day of month number, centered)
        new TableCell({
          width: { size: 10, type: WidthType.PERCENTAGE },
          margins: { top: 50, bottom: 50, left: 50, right: 50 },
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: String(day.dayOfMonth),
                  font: FONT_NAME,
                  size: 19,
                  bold: isSat || isSun,
                }),
              ],
            }),
          ],
        }),
        // Activities
        new TableCell({
          width: { size: 72, type: WidthType.PERCENTAGE },
          margins: { top: 50, bottom: 50, left: 90, right: 90 },
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              children: [
                new TextRun({
                  text: activitiesText,
                  font: FONT_NAME,
                  size: 19,
                  bold: isSat || isSun,
                }),
              ],
            }),
          ],
        }),
        // Remarks
        new TableCell({
          width: { size: 18, type: WidthType.PERCENTAGE },
          margins: { top: 50, bottom: 50, left: 50, right: 50 },
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: remarksText,
                  font: FONT_NAME,
                  size: 19,
                }),
              ],
            }),
          ],
        }),
      ],
    });
  });

  const mainTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [headerRow, ...dataRows],
  });

  // ================= 4. SIGNATORIES (Flows directly below table on Page 2) =================
  const sigSpacingPara = new Paragraph({ spacing: { before: 300, after: 80 }, children: [] });

  // Top Signatories: Prepared by (Left) & Verified by (Right)
  const topSignTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      bottom: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      left: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      right: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: 'auto' },
    },
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          // Left: Prepared by
          new TableCell({
            width: { size: 50, type: WidthType.PERCENTAGE },
            margins: { top: 60, bottom: 60, left: 80, right: 80 },
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                children: [
                  new TextRun({ text: 'Prepared by:\n\n\n\n', font: FONT_NAME, size: 20 }),
                  new TextRun({
                    text: metadata.employeeName.toUpperCase() + '\n',
                    font: FONT_NAME,
                    size: 20,
                    bold: true,
                  }),
                  new TextRun({
                    text: metadata.employeePosition,
                    font: FONT_NAME,
                    size: 19,
                  }),
                ],
              }),
            ],
          }),
          // Right: Verified by (Immediate Head)
          new TableCell({
            width: { size: 50, type: WidthType.PERCENTAGE },
            margins: { top: 60, bottom: 60, left: 80, right: 80 },
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                children: [
                  new TextRun({ text: 'Verified by:\n\n\n\n', font: FONT_NAME, size: 20 }),
                  new TextRun({
                    text: metadata.verifiedByName.toUpperCase() + '\n',
                    font: FONT_NAME,
                    size: 20,
                    bold: true,
                  }),
                  new TextRun({
                    text: metadata.verifiedByPosition,
                    font: FONT_NAME,
                    size: 19,
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  // Approved by (Center Bottom)
  const approvedSpace = new Paragraph({ spacing: { before: 360, after: 60 }, children: [] });

  const approvedTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      bottom: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      left: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      right: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: 'auto' },
    },
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          new TableCell({
            width: { size: 100, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({ text: 'Approved by:\n\n\n\n', font: FONT_NAME, size: 20 }),
                  new TextRun({
                    text: metadata.approvedByName.toUpperCase() + '\n',
                    font: FONT_NAME,
                    size: 20,
                    bold: true,
                  }),
                  new TextRun({
                    text: metadata.approvedByPosition,
                    font: FONT_NAME,
                    size: 19,
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  // ================= 5. ATTACHMENTS FOR VERIFICATION (1 Dedicated Page Per Photo) =================
  const attachmentParagraphs: Paragraph[] = [];

  for (const day of daysList) {
    const photos = getEntryPhotos(day);
    if (photos.length === 0) continue;

    for (let photoIdx = 0; photoIdx < photos.length; photoIdx++) {
      const photoSrc = photos[photoIdx];
      const imgData = await resolveImageBytes(photoSrc);
      if (!imgData) continue;

      const photoLabel = photos.length > 1 ? ` (Photo ${photoIdx + 1} of ${photos.length})` : '';

      // Dedicated Page for each photo: pageBreakBefore: true
      attachmentParagraphs.push(
        new Paragraph({
          pageBreakBefore: true,
          alignment: AlignmentType.CENTER,
          spacing: { before: 200, after: 120 },
          children: [
            new TextRun({
              text: 'ATTACHMENTS FOR VERIFICATION',
              font: FONT_NAME,
              size: 24, // 12pt bold
              bold: true,
            }),
          ],
        })
      );

      // Single line header matching template: Date: ...   Activity: ...
      attachmentParagraphs.push(
        new Paragraph({
          alignment: AlignmentType.LEFT,
          spacing: { before: 40, after: 160 },
          children: [
            new TextRun({
              text: 'Date: ',
              font: FONT_NAME,
              size: 20, // 10pt
              bold: true,
            }),
            new TextRun({
              text: `${day.date} (${day.fullDayName.toUpperCase()})${photoLabel}   `,
              font: FONT_NAME,
              size: 20,
            }),
            new TextRun({
              text: 'Activity: ',
              font: FONT_NAME,
              size: 20,
              bold: true,
            }),
            new TextRun({
              text: `${day.activities || 'Official duty logged'}`,
              font: FONT_NAME,
              size: 20,
            }),
          ],
        })
      );

      // Embed clear and large photo occupying the page body
      attachmentParagraphs.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [
            new ImageRun({
              data: imgData.data,
              transformation: {
                width: 510,
                height: 350,
              },
              type: imgData.type,
            }),
          ],
        })
      );
    }
  }

  // Assemble Complete Document in 8.5 x 13 in (Folio / Philippine Legal)
  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            size: {
              width: 12240,  // 8.5 inches (8.5 * 1440 dxa)
              height: 18720, // 13.0 inches (13.0 * 1440 dxa) - Folio / F4
            },
            margin: {
              top: 1080,     // 0.75 in (54 pt / 72 pt)
              bottom: 1080,
              left: 1080,
              right: 1080,
            },
          },
        },
        children: [
          headerPara,
          metaTable,
          spacingPara,
          mainTable,
          sigSpacingPara,
          topSignTable,
          approvedSpace,
          approvedTable,
          ...attachmentParagraphs,
        ],
      },
    ],
  });

  return await Packer.toBlob(doc);
}

/**
 * Triggers browser download of generated Blob
 */
export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
