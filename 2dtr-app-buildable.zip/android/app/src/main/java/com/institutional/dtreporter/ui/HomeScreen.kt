package com.institutional.dtreporter.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.institutional.dtreporter.util.InstitutionalMetadata
import java.io.File
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Main HomeScreen Composable displaying the full monthly DTR schedule,
 * fast month navigation, institutional metadata settings, and DOCX exporter.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val selectedYearMonth by viewModel.selectedYearMonth.collectAsState()
    val daysList by viewModel.daysList.collectAsState()
    val monthlyStats by viewModel.monthlyStats.collectAsState()
    val exportStatus by viewModel.exportStatus.collectAsState()
    val editingDay by viewModel.editingDay.collectAsState()
    val filterQuery by viewModel.filterQuery.collectAsState()
    val metadata by viewModel.metadata.collectAsState()

    var showMetadataDialog by remember { mutableStateOf(false) }

    // React to export state changes and present feedback via Snackbar
    LaunchedEffect(exportStatus) {
        when (val status = exportStatus) {
            is ExportStatus.Success -> {
                snackbarHostState.showSnackbar(
                    message = "DOCX successfully saved to: ${status.filePath}",
                    duration = SnackbarDuration.Long
                )
                viewModel.dismissExportStatus()
            }
            is ExportStatus.Error -> {
                snackbarHostState.showSnackbar(
                    message = "Export error: ${status.message}",
                    duration = SnackbarDuration.Long
                )
                viewModel.dismissExportStatus()
            }
            else -> Unit
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Daily Time Record",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = selectedYearMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.previousMonth() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Month")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.nextMonth() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Month")
                    }

                    // Auto-tag weekends quick button
                    IconButton(
                        onClick = { viewModel.autoTagWeekends() },
                        title = "Auto-tag Weekends"
                    ) {
                        Icon(Icons.Default.Weekend, contentDescription = "Auto-tag Weekends")
                    }

                    // Edit institutional profile metadata
                    IconButton(onClick = { showMetadataDialog = true }) {
                        Icon(Icons.Default.Badge, contentDescription = "Edit Profile & Agency")
                    }

                    // Export DOCX Action Button
                    Button(
                        onClick = { viewModel.exportToWordDocument(context) },
                        modifier = Modifier.padding(end = 8.dp),
                        enabled = exportStatus !is ExportStatus.Exporting,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        if (exportStatus is ExportStatus.Exporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Exporting...", fontSize = 12.sp)
                        } else {
                            Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export DOCX", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    // Find today's entry or open first uncompleted weekday
                    val todayDayOfMonth = LocalDate.now().dayOfMonth
                    val target = daysList.find { it.dayOfMonth == todayDayOfMonth } ?: daysList.firstOrNull()
                    if (target != null) {
                        viewModel.openEditDialog(target)
                    }
                },
                icon = { Icon(Icons.Default.EditCalendar, contentDescription = null) },
                text = { Text("Log Today") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 1. Monthly Summary Statistics Strip
            MonthlySummaryStrip(stats = monthlyStats)

            // 2. Filter Tabs (Segmented bar)
            FilterBar(
                currentFilter = filterQuery,
                onFilterSelected = { viewModel.setFilter(it) }
            )

            // 3. Daily Records List
            if (daysList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No records match current filter.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(daysList, key = { it.dateString }) { dayModel ->
                        DayCard(
                            day = dayModel,
                            onClick = { viewModel.openEditDialog(dayModel) }
                        )
                    }
                    // Bottom spacer for FAB breathing room
                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }

    // Modal Sheet for Day Editing
    editingDay?.let { day ->
        DailyEntryDialog(
            dayModel = day,
            onDismiss = { viewModel.dismissEditDialog() },
            onSave = { dateStr, dayOfMonth, act, rem, stat, photo ->
                viewModel.saveEntry(dateStr, dayOfMonth, act, rem, stat, photo)
            }
        )
    }

    // Institutional Metadata Configuration Dialog
    if (showMetadataDialog) {
        InstitutionalMetadataDialog(
            currentMetadata = metadata,
            onDismiss = { showMetadataDialog = false },
            onSave = { newMeta ->
                viewModel.updateMetadata(newMeta)
                showMetadataDialog = false
            }
        )
    }
}

/**
 * Summary KPI strip displaying days tally.
 */
@Composable
fun MonthlySummaryStrip(stats: MonthlyStats) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatItem(label = "Total Days", value = stats.totalDays.toString())
            StatDivider()
            StatItem(label = "Accomplished", value = stats.accomplishedDays.toString(), color = Color(0xFF16A34A))
            StatDivider()
            StatItem(label = "Leave", value = stats.leaveDays.toString(), color = Color(0xFFD97706))
            StatDivider()
            StatItem(label = "Travel", value = stats.travelDays.toString(), color = Color(0xFF2563EB))
            StatDivider()
            StatItem(label = "Proof Photos", value = stats.photosAttached.toString(), color = Color(0xFF7C3AED))
        }
    }
}

@Composable
fun StatItem(label: String, value: String, color: Color = MaterialTheme.colorScheme.onSurface) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun StatDivider() {
    Box(
        modifier = Modifier
            .height(24.dp)
            .width(1.dp)
            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    )
}

/**
 * Filter Segmented Chips
 */
@Composable
fun FilterBar(
    currentFilter: String,
    onFilterSelected: (String) -> Unit
) {
    val filters = listOf("All", "Weekdays", "Accomplished", "Leave", "Official Travel", "Photos")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        filters.take(4).forEach { filter ->
            val isSelected = currentFilter == filter
            FilterChip(
                selected = isSelected,
                onClick = { onFilterSelected(filter) },
                label = { Text(filter, fontSize = 12.sp) }
            )
        }
    }
}

/**
 * Individual Daily Record Card with Day badge, status indicator,
 * activities text preview, and proof photo thumbnail.
 */
@Composable
fun DayCard(
    day: DayCardUiModel,
    onClick: () -> Unit
) {
    val cardBorderColor = if (day.isWeekend) {
        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
    } else {
        MaterialTheme.colorScheme.outlineVariant
    }

    val containerColor = if (day.isWeekend) {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
    } else {
        MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, cardBorderColor),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Day badge
            Column(
                modifier = Modifier
                    .width(48.dp)
                    .height(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (day.isWeekend) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.primaryContainer
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = String.format(Locale.US, "%02d", day.dayOfMonth),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (day.isWeekend) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = day.dayOfWeekName,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = if (day.isWeekend) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Body Content (Activities & Remarks)
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Status text
                    Text(
                        text = if (day.isWeekend && day.activities.isBlank()) "WEEKEND" else day.status,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = when (day.status) {
                            "Accomplished" -> Color(0xFF16A34A)
                            "Leave" -> Color(0xFFD97706)
                            "Official Travel" -> Color(0xFF2563EB)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )

                    // Remarks tag if present
                    if (day.remarks.isNotBlank()) {
                        Text(
                            text = day.remarks,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Activities text
                Text(
                    text = when {
                        day.activities.isNotBlank() -> day.activities
                        day.isWeekend -> "Weekend — No official duty scheduled"
                        else -> "No activities logged yet (Tap to record)"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (day.activities.isNotBlank()) MaterialTheme.colorScheme.onSurface
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Photo preview if attached
            if (!day.photoPath.isNullOrBlank() && File(day.photoPath).exists()) {
                Spacer(modifier = Modifier.width(10.dp))
                AsyncImage(
                    model = File(day.photoPath),
                    contentDescription = "Proof Thumbnail",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(6.dp))
                )
            } else {
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Edit Day",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
    }
}

/**
 * Dialog to adjust institutional metadata for official reporting.
 */
@Composable
fun InstitutionalMetadataDialog(
    currentMetadata: InstitutionalMetadata,
    onDismiss: () -> Unit,
    onSave: (InstitutionalMetadata) -> Unit
) {
    var name by remember { mutableStateOf(currentMetadata.employeeName) }
    var position by remember { mutableStateOf(currentMetadata.positionTitle) }
    var agency by remember { mutableStateOf(currentMetadata.agencyOrInstitution) }
    var dept by remember { mutableStateOf(currentMetadata.departmentOrCampus) }
    var supervisor by remember { mutableStateOf(currentMetadata.immediateSupervisor) }
    var supervisorPos by remember { mutableStateOf(currentMetadata.supervisorPosition) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Institutional Report Settings") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Employee Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = position,
                    onValueChange = { position = it },
                    label = { Text("Position Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = agency,
                    onValueChange = { agency = it },
                    label = { Text("Agency / Institution") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dept,
                    onValueChange = { dept = it },
                    label = { Text("Department / College") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = supervisor,
                    onValueChange = { supervisor = it },
                    label = { Text("Immediate Supervisor") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = supervisorPos,
                    onValueChange = { supervisorPos = it },
                    label = { Text("Supervisor Position") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        InstitutionalMetadata(
                            employeeName = name,
                            positionTitle = position,
                            agencyOrInstitution = agency,
                            departmentOrCampus = dept,
                            immediateSupervisor = supervisor,
                            supervisorPosition = supervisorPos
                        )
                    )
                }
            ) {
                Text("Save Settings")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
