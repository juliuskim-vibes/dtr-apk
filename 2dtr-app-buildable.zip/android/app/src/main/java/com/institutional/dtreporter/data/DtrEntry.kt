package com.institutional.dtreporter.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing a single Daily Time Record (DTR) and Accomplishment log entry.
 *
 * @property date ISO-8601 formatted date string ("YYYY-MM-DD"), used as the Primary Key.
 * @property dayOfMonth Calendar day index (1 to 28/29/30/31) for quick sorting and display.
 * @property activities Detailed multiline description of tasks, projects, or accomplishments.
 * @property remarks Official institutional annotations (e.g., "SATURDAY", "SUNDAY", "HOLIDAY", "WFH").
 * @property photoPath Absolute file path in app-private storage where the proof image is preserved.
 * @property status Workflow status category: "Accomplished", "Leave", or "Official Travel".
 */
@Entity(tableName = "dtr_entries")
data class DtrEntry(
    @PrimaryKey
    val date: String,             // Format: "YYYY-MM-DD"
    val dayOfMonth: Int,          // 1 .. 31
    val activities: String = "",  // Accomplishment text
    val remarks: String = "",     // Auto-filled or customized remark
    val photoPath: String? = null,// Path in context.filesDir
    val status: String = "Accomplished" // Accomplished | Leave | Official Travel
)
