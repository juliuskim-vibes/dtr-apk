package com.institutional.dtreporter.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.institutional.dtreporter.util.FileUtil
import java.io.File

/**
 * Modal BottomSheet / Dialog allowing the user to log daily accomplishments,
 * attach photographic proof via camera, select status, and customize remarks.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyEntryDialog(
    dayModel: DayCardUiModel,
    onDismiss: () -> Unit,
    onSave: (
        dateString: String,
        dayOfMonth: Int,
        activities: String,
        remarks: String,
        status: String,
        photoPath: String?
    ) -> Unit
) {
    val context = LocalContext.current

    var activities by remember { mutableStateOf(dayModel.activities) }
    var remarks by remember { mutableStateOf(dayModel.remarks) }
    var selectedStatus by remember {
        mutableStateOf(
            if (dayModel.status in listOf("Accomplished", "Leave", "Official Travel"))
                dayModel.status
            else if (dayModel.isWeekend) "Weekend" else "Accomplished"
        )
    }
    var currentPhotoPath by remember { mutableStateOf(dayModel.photoPath) }
    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }
    var statusDropdownExpanded by remember { mutableStateOf(false) }

    // Launcher for TakePicture (system camera contract)
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && tempCameraUri != null) {
            val internalPath = FileUtil.copyUriToInternalStorage(
                context = context,
                sourceUri = tempCameraUri!!,
                dateKey = dayModel.dateString
            )
            if (internalPath != null) {
                currentPhotoPath = internalPath
            }
        }
    }

    // Launcher for Photo Picker / Gallery fallback
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val internalPath = FileUtil.copyUriToInternalStorage(
                context = context,
                sourceUri = uri,
                dateKey = dayModel.dateString
            )
            if (internalPath != null) {
                currentPhotoPath = internalPath
            }
        }
    }

    val statusOptions = listOf("Accomplished", "Leave", "Official Travel", "Weekend")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header: Day & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Day ${dayModel.dayOfMonth} · ${dayModel.dayOfWeekName}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = dayModel.dateString,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 1. Status Dropdown Selector
            Text(
                text = "Workflow Status",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))
            ExposedDropdownMenuBox(
                expanded = statusDropdownExpanded,
                onExpandedChange = { statusDropdownExpanded = !statusDropdownExpanded }
            ) {
                OutlinedTextField(
                    value = selectedStatus,
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                ExposedDropdownMenu(
                    expanded = statusDropdownExpanded,
                    onDismissRequest = { statusDropdownExpanded = false }
                ) {
                    statusOptions.forEach { status ->
                        DropdownMenuItem(
                            text = { Text(status) },
                            onClick = {
                                selectedStatus = status
                                statusDropdownExpanded = false
                                // Auto-fill common remarks if user changes status
                                if (status == "Leave" && remarks.isBlank()) {
                                    remarks = "ON LEAVE"
                                } else if (status == "Official Travel" && remarks.isBlank()) {
                                    remarks = "OFFICIAL TRAVEL (TRAVEL ORDER)"
                                }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 2. Multiline Activities Text Field
            Text(
                text = "Activities Undertaken / Accomplishments",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = activities,
                onValueChange = { activities = it },
                placeholder = {
                    Text(
                        if (dayModel.isWeekend)
                            "Optional: Log weekend tasks or leave empty for default weekend tag..."
                        else
                            "e.g., Prepared lesson modules, conducted laboratory class, attended department meeting..."
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp),
                shape = RoundedCornerShape(12.dp),
                minLines = 4,
                maxLines = 8
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 3. Remarks & Institutional Quick Chips
            Text(
                text = "Remarks / Official Tag",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = remarks,
                onValueChange = { remarks = it },
                placeholder = { Text("e.g., SATURDAY, SUNDAY, HOLIDAY, WFH") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))
            // Quick suggestion chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("SATURDAY", "SUNDAY", "HOLIDAY", "WFH", "FIELD WORK").forEach { chipText ->
                    SuggestionChip(
                        onClick = { remarks = chipText },
                        label = { Text(chipText, fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 4. Photographic Proof & Camera Capture Section
            Text(
                text = "Photographic Proof / Attachment",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (!currentPhotoPath.isNullOrBlank() && File(currentPhotoPath!!).exists()) {
                // Show thumbnail preview with delete button
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            AsyncImage(
                                model = File(currentPhotoPath!!),
                                contentDescription = "Attached Proof",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Photo Attached",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(
                                    onClick = {
                                        val uri = FileUtil.createCameraTempUri(context)
                                        tempCameraUri = uri
                                        cameraLauncher.launch(uri)
                                    }
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Retake")
                                }

                                TextButton(
                                    onClick = {
                                        FileUtil.deleteInternalPhoto(currentPhotoPath)
                                        currentPhotoPath = null
                                    },
                                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Remove")
                                }
                            }
                        }
                    }
                }
            } else {
                // Camera Launch / Pick action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val uri = FileUtil.createCameraTempUri(context)
                            tempCameraUri = uri
                            cameraLauncher.launch(uri)
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Camera")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Take Photo")
                    }

                    OutlinedButton(
                        onClick = { galleryLauncher.launch("image/*") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = "Gallery")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Gallery")
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // 5. Action Buttons (Cancel / Save)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Cancel")
                }

                Button(
                    onClick = {
                        onSave(
                            dayModel.dateString,
                            dayModel.dayOfMonth,
                            activities,
                            remarks,
                            selectedStatus,
                            currentPhotoPath
                        )
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Save Record")
                }
            }
        }
    }
}
