package com.institutional.dtreporter.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Utility helper class for camera image capture, internal storage persistence,
 * and scoped storage document routing.
 */
object FileUtil {

    private const val PHOTO_DIR_NAME = "photos"
    private const val CACHE_DIR_NAME = "camera_captures"

    /**
     * Creates a temporary cache file and generates a content:// Uri via FileProvider
     * ready to be supplied to [androidx.activity.result.contract.ActivityResultContracts.TakePicture].
     */
    fun createCameraTempUri(context: Context): Uri {
        val cacheFolder = File(context.cacheDir, CACHE_DIR_NAME).apply {
            if (!exists()) mkdirs()
        }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val tempFile = File.createTempFile("PROOF_${timeStamp}_", ".jpg", cacheFolder)
        val authority = "${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, tempFile)
    }

    /**
     * Saves a [Bitmap] directly to the app-private internal directory (context.filesDir/photos).
     * This avoids external storage permissions while keeping proof images private and persistent.
     *
     * @return Absolute file path on disk.
     */
    fun saveBitmapToInternalStorage(context: Context, bitmap: Bitmap, dateKey: String): String {
        val photosDir = File(context.filesDir, PHOTO_DIR_NAME).apply {
            if (!exists()) mkdirs()
        }
        val fileName = "DTR_PROOF_${dateKey}.jpg"
        val destinationFile = File(photosDir, fileName)

        FileOutputStream(destinationFile).use { outStream ->
            // Compress with high visual clarity for institutional proof review
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outStream)
            outStream.flush()
        }

        return destinationFile.absolutePath
    }

    /**
     * Copies an image from a content URI (e.g. from TakePicture cache or Gallery picker)
     * into the app-private internal storage (context.filesDir/photos).
     *
     * @return Absolute file path on disk.
     */
    fun copyUriToInternalStorage(context: Context, sourceUri: Uri, dateKey: String): String? {
        return try {
            val photosDir = File(context.filesDir, PHOTO_DIR_NAME).apply {
                if (!exists()) mkdirs()
            }
            val fileName = "DTR_PROOF_${dateKey}.jpg"
            val destinationFile = File(photosDir, fileName)

            val inputStream: InputStream? = context.contentResolver.openInputStream(sourceUri)
            inputStream?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            destinationFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Safely deletes an internal photo if the user removes or replaces it.
     */
    fun deleteInternalPhoto(filePath: String?): Boolean {
        if (filePath.isNullOrBlank()) return false
        val file = File(filePath)
        return if (file.exists()) file.delete() else false
    }

    /**
     * Decodes a scaled Bitmap from an absolute file path for previewing in UI without OOM errors.
     */
    fun loadScaledBitmap(filePath: String, maxDimension: Int = 1024): Bitmap? {
        val file = File(filePath)
        if (!file.exists()) return null

        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(filePath, options)

        var sampleSize = 1
        while (options.outWidth / sampleSize > maxDimension || options.outHeight / sampleSize > maxDimension) {
            sampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
        }
        return BitmapFactory.decodeFile(filePath, decodeOptions)
    }

    /**
     * Creates an OutputStream to write the exported Word document directly to the
     * device's public Downloads directory. Supports modern Scoped Storage (Android 10+ MediaStore)
     * and legacy Environment.getExternalStoragePublicDirectory.
     */
    fun openDownloadsOutputStream(
        context: Context,
        fileName: String,
        mimeType: String = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ): Pair<OutputStream?, String?> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                Pair(context.contentResolver.openOutputStream(uri), "Downloads/$fileName")
            } else {
                Pair(null, null)
            }
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val targetFile = File(downloadsDir, fileName)
            Pair(FileOutputStream(targetFile), targetFile.absolutePath)
        }
    }
}
