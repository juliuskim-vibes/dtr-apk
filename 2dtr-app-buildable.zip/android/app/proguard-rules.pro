# Room Database rules
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Apache POI POI-OOXML rules
-dontwarn org.apache.poi.**
-dontwarn org.openxmlformats.**
-dontwarn schemasMicrosoftComOffice**
-dontwarn org.apache.xmlbeans.**
-keep class org.apache.poi.** { *; }
-keep class org.openxmlformats.** { *; }
-keep class org.apache.xmlbeans.** { *; }

# Coil image loader rules
-dontwarn coil.**
-keep class coil.** { *; }
